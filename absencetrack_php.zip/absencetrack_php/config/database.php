<?php
define('DB_HOST', 'localhost');
define('DB_NAME', 'absencetrack');
define('DB_USER', 'root');       // Changer selon votre config
define('DB_PASS', '');           // Changer selon votre config
define('DB_CHARSET', 'utf8mb4');

function getPDO(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;
        try {
            $pdo = new PDO($dsn, DB_USER, DB_PASS, [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            ]);
        } catch (PDOException $e) {
            die('<div style="font-family:sans-serif;padding:40px;color:#991b1b;background:#fef2f2;border:1px solid #fca5a5;border-radius:8px;margin:40px auto;max-width:600px">
                <h2>Erreur de connexion à la base de données</h2>
                <p>' . htmlspecialchars($e->getMessage()) . '</p>
                <p style="margin-top:16px;font-size:13px;color:#666">Vérifiez les paramètres dans <code>config/database.php</code></p>
            </div>');
        }
    }
    return $pdo;
}
