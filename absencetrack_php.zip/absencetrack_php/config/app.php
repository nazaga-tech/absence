<?php
define('APP_NAME', 'AbsenceTrack');
define('APP_ROOT', dirname(__DIR__));
define('BASE_URL', '/absencetrack_php');   // Dossier de votre projet dans htdocs

// Session
session_start();

// Helpers flash messages
function flash(string $msg, string $type = 'success'): void {
    $_SESSION['flash'] = ['msg' => $msg, 'type' => $type];
}

function getFlash(): ?array {
    $f = $_SESSION['flash'] ?? null;
    unset($_SESSION['flash']);
    return $f;
}

// Redirection
function redirect(string $url): void {
    header('Location: ' . BASE_URL . $url);
    exit;
}

// Nettoyage XSS
function e(mixed $v): string {
    return htmlspecialchars((string)($v ?? ''), ENT_QUOTES, 'UTF-8');
}

// Badge statut absence
function badgeStatut(string $s): string {
    return match($s) {
        'J' => '<span class="badge badge-success">Justifiée</span>',
        'I' => '<span class="badge badge-danger">Injustifiée</span>',
        default => '<span class="badge badge-warning">En attente</span>',
    };
}

// Badge statut période
function badgePeriode(string $s): string {
    return match($s) {
        'A' => '<span class="badge badge-success">Active</span>',
        'V' => '<span class="badge badge-warning">À venir</span>',
        default => '<span class="badge badge-info">Clôturée</span>',
    };
}
