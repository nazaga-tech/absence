# AbsenceTrack — Version PHP

Application web PHP/MySQL de gestion des absences étudiantes.

---

## Prérequis

- PHP 7.4+ (ou PHP 8.x recommandé)
- MySQL 5.7+ ou MariaDB 10.3+
- Serveur web : XAMPP, WAMP, MAMP ou Laragon (Windows) / LAMP (Linux)

---

## Installation étape par étape

### Étape 1 — Copier les fichiers

Placer le dossier `absencetrack_php` dans :
- **XAMPP/WAMP** : `C:/xampp/htdocs/` ou `C:/wamp64/www/`
- **MAMP** : `/Applications/MAMP/htdocs/`
- **Linux/LAMP** : `/var/www/html/`

### Étape 2 — Créer la base de données

1. Ouvrir **phpMyAdmin** → `http://localhost/phpmyadmin`
2. Cliquer sur **"Nouvelle base de données"**
3. Nom : `absencetrack` → Cliquer **Créer**
4. Sélectionner la base `absencetrack` dans la liste
5. Aller dans l'onglet **SQL** ou **Importer**
6. Coller/importer le fichier `sql/database.sql`
7. Cliquer **Exécuter**

### Étape 3 — Configurer la connexion

Ouvrir `config/database.php` et modifier si nécessaire :

```php
define('DB_HOST', 'localhost');   // Laisser localhost
define('DB_NAME', 'absencetrack'); // Nom de la base
define('DB_USER', 'root');         // Utilisateur MySQL (root par défaut)
define('DB_PASS', '');             // Mot de passe (vide par défaut sur XAMPP)
```

> Sur MAMP : le mot de passe par défaut est `root`

### Étape 4 — Lancer l'application

Ouvrir le navigateur : `http://localhost/absencetrack_php/`

---

## Structure des fichiers

```
absencetrack_php/
├── index.php                  → Tableau de bord
├── config/
│   ├── database.php           → Connexion MySQL (PDO)
│   └── app.php                → Configuration générale
├── includes/
│   ├── header.php             → En-tête + sidebar (inclus dans toutes les pages)
│   └── footer.php             → Pied de page
├── assets/
│   ├── css/style.css          → Styles CSS
│   └── js/app.js              → JavaScript
├── modules/
│   ├── absences.php           → Liste générale des absences
│   ├── horaires.php           → Planning hebdomadaire
│   ├── rapports.php           → Statistiques
│   ├── parametrage/
│   │   ├── periodes.php       → Périodes d'évaluation (CRUD)
│   │   ├── matieres.php       → Matières (CRUD)
│   │   ├── enseignants.php    → Enseignants (CRUD)
│   │   └── filieres.php       → Filières (CRUD)
│   ├── saisie/
│   │   ├── inscription.php    → Inscription étudiants + import CSV
│   │   ├── presences.php      → Feuille d'appel (saisie présences/absences)
│   │   ├── message.php        → Envoi de message à un absent
│   │   └── justification.php  → Justification des absences par lot
│   └── edition/
│       └── absences_justifiees.php → Liste absences justifiées + impression
└── sql/
    └── database.sql           → Schéma + données de démonstration
```

---

## Fonctionnalités

| Module | Fonctionnalité |
|--------|---------------|
| Tableau de bord | Stats du mois, alertes absentéisme, dernières absences |
| Paramétrage | CRUD périodes, matières, enseignants, filières |
| Inscription | Formulaire + liste filtrée + import CSV |
| Feuille d'appel | Sélection séance → cochage présents/absents → enregistrement |
| Messagerie | Envoi de message aux étudiants absents |
| Justification | Traitement par lot (En attente → Justifiée/Injustifiée) |
| Édition | Liste absences justifiées avec filtres + impression CSS |
| Rapports | Classements par filière, matière, top absentéistes |

---

## Problèmes courants

**Page blanche** → Activer les erreurs PHP : ajouter en haut de `index.php` :
```php
ini_set('display_errors', 1); error_reporting(E_ALL);
```

**Erreur de connexion** → Vérifier que MySQL est démarré dans XAMPP/WAMP et que `DB_PASS` est correct.

**Page non trouvée (404)** → Vérifier que le dossier est bien dans `htdocs/` et que l'URL est `http://localhost/absencetrack_php/`.
