  </div><!-- /content -->
</main>
<script src="<?= BASE_URL ?>/assets/js/app.js"></script>
</body>
</html>
