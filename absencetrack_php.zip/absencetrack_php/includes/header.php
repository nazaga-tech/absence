<?php
require_once dirname(__DIR__) . '/config/app.php';
require_once dirname(__DIR__) . '/config/database.php';
$flash = getFlash();
$currentPage = $currentPage ?? '';
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>AbsenceTrack — <?= e($pageTitle ?? 'Accueil') ?></title>
<link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@300;400;500;600&family=DM+Serif+Display&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
</head>
<body>

<aside class="sidebar">
  <div class="logo">
    <div class="logo-title">AbsenceTrack</div>
    <div class="logo-sub">Gestion des absences</div>
  </div>
  <nav class="nav">
    <div class="nav-section">Principal</div>
    <a href="<?= BASE_URL ?>/" class="nav-item <?= $currentPage==='dashboard'?'active':'' ?>"><span class="nav-icon">⊞</span> Tableau de bord</a>
    <a href="<?= BASE_URL ?>/modules/absences.php" class="nav-item <?= $currentPage==='absences'?'active':'' ?>"><span class="nav-icon">📋</span> Absences</a>
    <a href="<?= BASE_URL ?>/modules/horaires.php" class="nav-item <?= $currentPage==='horaires'?'active':'' ?>"><span class="nav-icon">🕐</span> Horaires</a>

    <div class="nav-section">Module 1 — Paramétrage</div>
    <a href="<?= BASE_URL ?>/modules/parametrage/periodes.php" class="nav-item <?= $currentPage==='periodes'?'active':'' ?>"><span class="nav-icon">📅</span> Périodes</a>
    <a href="<?= BASE_URL ?>/modules/parametrage/matieres.php" class="nav-item <?= $currentPage==='matieres'?'active':'' ?>"><span class="nav-icon">📚</span> Matières</a>
    <a href="<?= BASE_URL ?>/modules/parametrage/enseignants.php" class="nav-item <?= $currentPage==='enseignants'?'active':'' ?>"><span class="nav-icon">👨‍🏫</span> Enseignants</a>
    <a href="<?= BASE_URL ?>/modules/parametrage/filieres.php" class="nav-item <?= $currentPage==='filieres'?'active':'' ?>"><span class="nav-icon">🏛️</span> Filières</a>

    <div class="nav-section">Module 2 — Saisie</div>
    <a href="<?= BASE_URL ?>/modules/saisie/inscription.php" class="nav-item <?= $currentPage==='inscription'?'active':'' ?>"><span class="nav-icon">🎓</span> Inscription étudiants</a>
    <a href="<?= BASE_URL ?>/modules/saisie/presences.php" class="nav-item <?= $currentPage==='presences'?'active':'' ?>"><span class="nav-icon">✅</span> Présences / Absences</a>
    <a href="<?= BASE_URL ?>/modules/saisie/justification.php" class="nav-item <?= $currentPage==='justification'?'active':'' ?>"><span class="nav-icon">🔍</span> Justification</a>

    <div class="nav-section">Module 3 — Édition</div>
    <a href="<?= BASE_URL ?>/modules/edition/absences_justifiees.php" class="nav-item <?= $currentPage==='edition'?'active':'' ?>"><span class="nav-icon">📄</span> Absences justifiées</a>
    <a href="<?= BASE_URL ?>/modules/rapports.php" class="nav-item <?= $currentPage==='rapports'?'active':'' ?>"><span class="nav-icon">📊</span> Rapports</a>
  </nav>
  <div class="sidebar-footer">
    <div style="display:flex;align-items:center;gap:9px;padding:8px 10px">
      <div class="avatar" style="width:30px;height:30px;background:var(--accent);font-size:11px">AD</div>
      <div><div style="font-size:12px;color:#fff;font-weight:500">Admin</div><div style="font-size:10px;color:rgba(255,255,255,.4)">Administrateur</div></div>
    </div>
  </div>
</aside>

<main class="main">
  <div class="topbar">
    <div class="page-title"><?= e($pageTitle ?? '') ?></div>
    <div class="topbar-actions"><?= $topbarActions ?? '' ?></div>
  </div>
  <?php if ($flash): ?>
  <div class="messages-container">
    <div class="alert alert-<?= $flash['type'] === 'success' ? 'success' : 'danger' ?>">
      <span><?= $flash['type'] === 'success' ? '✅' : '❌' ?></span>
      <div><?= e($flash['msg']) ?></div>
    </div>
  </div>
  <?php endif; ?>
  <div class="content">
