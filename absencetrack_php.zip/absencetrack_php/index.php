<?php
$pageTitle  = 'Tableau de bord';
$currentPage = 'dashboard';
require_once 'includes/header.php';
$pdo = getPDO();

$today = date('Y-m-d');
$monthStart = date('Y-m-01');

$totalAbsences = $pdo->query("SELECT COUNT(*) FROM absence WHERE DATE(created_at) >= '$monthStart'")->fetchColumn();
$injustifiees  = $pdo->query("SELECT COUNT(*) FROM absence WHERE statut='I' AND DATE(created_at) >= '$monthStart'")->fetchColumn();
$enAttente     = $pdo->query("SELECT COUNT(*) FROM absence WHERE statut='A'")->fetchColumn();
$totalEtu      = $pdo->query("SELECT COUNT(*) FROM etudiant")->fetchColumn();

$parMatiere = $pdo->query("
    SELECT m.nom_mati, COUNT(a.id) as total
    FROM absence a
    JOIN horaire h ON a.horaire_id = h.id
    JOIN enseignement e ON h.enseignement_id = e.id
    JOIN matiere m ON e.matiere_id = m.id
    WHERE DATE(a.created_at) >= '$monthStart'
    GROUP BY m.id ORDER BY total DESC LIMIT 6
")->fetchAll();

$dernieres = $pdo->query("
    SELECT a.id, a.statut, a.created_at,
           et.prenom, et.nom, f.libelle as filiere,
           m.nom_mati, CONCAT('Pr. ', en.prenom, ' ', en.nom) as enseignant,
           h.date_periode
    FROM absence a
    JOIN etudiant et ON a.etudiant_id = et.id
    LEFT JOIN filiere f ON et.filiere_id = f.id
    JOIN horaire h ON a.horaire_id = h.id
    JOIN enseignement ens ON h.enseignement_id = ens.id
    JOIN matiere m ON ens.matiere_id = m.id
    JOIN enseignant en ON ens.enseignant_id = en.id
    ORDER BY a.created_at DESC LIMIT 8
")->fetchAll();

$alertes = $pdo->query("
    SELECT et.id, et.prenom, et.nom, f.libelle as filiere, COUNT(a.id) as nb_inj
    FROM etudiant et
    LEFT JOIN filiere f ON et.filiere_id = f.id
    JOIN absence a ON a.etudiant_id = et.id AND a.statut = 'I'
    GROUP BY et.id HAVING nb_inj >= 2
    ORDER BY nb_inj DESC LIMIT 5
")->fetchAll();
?>

<div class="stats-grid">
  <div class="stat-card">
    <div class="stat-icon" style="background:#fef2f2">🚨</div>
    <div class="stat-label">Absences ce mois</div>
    <div class="stat-value" style="color:var(--danger)"><?= $totalAbsences ?></div>
  </div>
  <div class="stat-card">
    <div class="stat-icon" style="background:#eff6ff">🎓</div>
    <div class="stat-label">Étudiants inscrits</div>
    <div class="stat-value" style="color:var(--info)"><?= $totalEtu ?></div>
  </div>
  <div class="stat-card">
    <div class="stat-icon" style="background:#fffbeb">⚠️</div>
    <div class="stat-label">En attente validation</div>
    <div class="stat-value" style="color:var(--warning)"><?= $enAttente ?></div>
  </div>
  <div class="stat-card">
    <div class="stat-icon" style="background:#fef2f2">❌</div>
    <div class="stat-label">Injustifiées ce mois</div>
    <div class="stat-value" style="color:var(--danger)"><?= $injustifiees ?></div>
  </div>
</div>

<?php if ($enAttente > 0): ?>
<div class="alert alert-warning">
  <span>⚠️</span>
  <div><?= $enAttente ?> absence(s) en attente de validation.
    <a href="<?= BASE_URL ?>/modules/saisie/justification.php?statut=A" style="color:inherit;font-weight:600">Traiter maintenant</a>
  </div>
</div>
<?php endif; ?>

<div class="two-cols">
  <div class="card">
    <div class="card-header"><div class="card-title">Absences par matière (ce mois)</div></div>
    <div style="padding:18px">
      <?php $max = $parMatiere[0]['total'] ?? 1; foreach ($parMatiere as $row): ?>
      <div style="margin-bottom:14px">
        <div style="display:flex;justify-content:space-between;margin-bottom:5px;font-size:13px">
          <span><?= e($row['nom_mati']) ?></span>
          <strong><?= $row['total'] ?></strong>
        </div>
        <div class="progress-track" style="width:100%">
          <div class="progress-fill" style="width:<?= round($row['total']/$max*100) ?>%;background:var(--accent)"></div>
        </div>
      </div>
      <?php endforeach; if (empty($parMatiere)): ?>
      <p style="color:var(--muted);text-align:center;padding:20px">Aucune absence ce mois</p>
      <?php endif; ?>
    </div>
  </div>

  <div class="card">
    <div class="card-header"><div class="card-title">Alertes — absentéisme</div></div>
    <div style="padding:16px">
      <?php if (empty($alertes)): ?>
        <p style="color:var(--muted);text-align:center;padding:20px">✅ Aucune alerte</p>
      <?php else: foreach ($alertes as $a): ?>
        <div style="display:flex;align-items:center;justify-content:space-between;padding:10px;border-radius:8px;background:#fef2f2;margin-bottom:8px">
          <div style="display:flex;align-items:center;gap:10px">
            <div class="avatar" style="width:28px;height:28px;background:var(--danger);font-size:10px"><?= strtoupper(substr($a['prenom'],0,1).substr($a['nom'],0,1)) ?></div>
            <div>
              <div style="font-size:13px;font-weight:500"><?= e($a['prenom'].' '.$a['nom']) ?></div>
              <div style="font-size:11px;color:var(--muted)"><?= e($a['filiere'] ?? '—') ?></div>
            </div>
          </div>
          <span class="badge badge-danger"><?= $a['nb_inj'] ?> inj.</span>
        </div>
      <?php endforeach; endif; ?>
    </div>
  </div>
</div>

<div class="card">
  <div class="card-header">
    <div class="card-title">Absences récentes</div>
    <a href="<?= BASE_URL ?>/modules/absences.php" class="btn btn-ghost btn-sm">Voir tout</a>
  </div>
  <table>
    <thead><tr><th>Étudiant</th><th>Matière</th><th>Enseignant</th><th>Date</th><th>Statut</th><th></th></tr></thead>
    <tbody>
      <?php foreach ($dernieres as $ab): ?>
      <tr>
        <td><div style="font-weight:500"><?= e($ab['prenom'].' '.$ab['nom']) ?></div>
            <div style="font-size:11px;color:var(--muted)"><?= e($ab['filiere'] ?? '—') ?></div></td>
        <td><?= e($ab['nom_mati']) ?></td>
        <td><?= e($ab['enseignant']) ?></td>
        <td><?= date('d/m/Y', strtotime($ab['date_periode'])) ?></td>
        <td><?= badgeStatut($ab['statut']) ?></td>
        <td><a href="<?= BASE_URL ?>/modules/absences.php?detail=<?= $ab['id'] ?>" class="btn btn-ghost btn-sm">Voir</a></td>
      </tr>
      <?php endforeach; if (empty($dernieres)): ?>
      <tr><td colspan="6" style="text-align:center;padding:30px;color:var(--muted)">Aucune absence enregistrée</td></tr>
      <?php endif; ?>
    </tbody>
  </table>
</div>

<?php require_once 'includes/footer.php'; ?>
