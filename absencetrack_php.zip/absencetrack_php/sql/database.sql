-- AbsenceTrack — Base de données MySQL/MariaDB
-- Créer la base puis exécuter ce fichier

SET NAMES utf8mb4;
SET foreign_key_checks = 0;

-- ─── Tables ───────────────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS diplome (
    id INT AUTO_INCREMENT PRIMARY KEY,
    libelle VARCHAR(100) NOT NULL UNIQUE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS periode_evaluation (
    id INT AUTO_INCREMENT PRIMARY KEY,
    libelle VARCHAR(150) NOT NULL,
    date_debut DATE NOT NULL,
    date_fin DATE NOT NULL,
    statut ENUM('A','V','C') DEFAULT 'V' COMMENT 'A=Active V=A venir C=Cloturee'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS filiere (
    id INT AUTO_INCREMENT PRIMARY KEY,
    code_fili VARCHAR(20) NOT NULL UNIQUE,
    libelle VARCHAR(150) NOT NULL,
    diplome_id INT,
    FOREIGN KEY (diplome_id) REFERENCES diplome(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS matiere (
    id INT AUTO_INCREMENT PRIMARY KEY,
    code_mati VARCHAR(20) NOT NULL UNIQUE,
    nom_mati VARCHAR(150) NOT NULL,
    volume_horaire INT NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS enseignant (
    id INT AUTO_INCREMENT PRIMARY KEY,
    identifiant VARCHAR(30) NOT NULL UNIQUE,
    nom VARCHAR(100) NOT NULL,
    prenom VARCHAR(100) NOT NULL,
    mail VARCHAR(150) NOT NULL UNIQUE,
    sexe ENUM('M','F') NOT NULL DEFAULT 'M'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS enseignement (
    id INT AUTO_INCREMENT PRIMARY KEY,
    enseignant_id INT NOT NULL,
    matiere_id INT NOT NULL,
    dat_enseignement DATE NOT NULL,
    volume_horaire INT DEFAULT 0,
    UNIQUE KEY uk_ens_mat (enseignant_id, matiere_id),
    FOREIGN KEY (enseignant_id) REFERENCES enseignant(id) ON DELETE CASCADE,
    FOREIGN KEY (matiere_id) REFERENCES matiere(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS etudiant (
    id INT AUTO_INCREMENT PRIMARY KEY,
    identifiant VARCHAR(30) NOT NULL UNIQUE,
    nom VARCHAR(100) NOT NULL,
    prenom VARCHAR(100) NOT NULL,
    mail VARCHAR(150) NOT NULL UNIQUE,
    sexe ENUM('M','F') NOT NULL DEFAULT 'M',
    filiere_id INT,
    FOREIGN KEY (filiere_id) REFERENCES filiere(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS horaire (
    id INT AUTO_INCREMENT PRIMARY KEY,
    enseignement_id INT NOT NULL,
    filiere_id INT NOT NULL,
    jour ENUM('LUN','MAR','MER','JEU','VEN','SAM') NOT NULL,
    heure_debut TIME NOT NULL,
    heure_fin TIME NOT NULL,
    date_periode DATE NOT NULL,
    volume_horaire INT DEFAULT 2,
    FOREIGN KEY (enseignement_id) REFERENCES enseignement(id) ON DELETE CASCADE,
    FOREIGN KEY (filiere_id) REFERENCES filiere(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS absence (
    id INT AUTO_INCREMENT PRIMARY KEY,
    etudiant_id INT NOT NULL,
    horaire_id INT NOT NULL,
    statut ENUM('A','J','I') DEFAULT 'A' COMMENT 'A=Attente J=Justifiee I=Injustifiee',
    motif TEXT,
    date_validation DATE,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uk_etu_hor (etudiant_id, horaire_id),
    FOREIGN KEY (etudiant_id) REFERENCES etudiant(id) ON DELETE CASCADE,
    FOREIGN KEY (horaire_id) REFERENCES horaire(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS message_absence (
    id INT AUTO_INCREMENT PRIMARY KEY,
    absence_id INT NOT NULL,
    contenu TEXT NOT NULL,
    envoye TINYINT(1) DEFAULT 0,
    envoye_le DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (absence_id) REFERENCES absence(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ─── Données de démonstration ─────────────────────────────────────────────────

INSERT INTO diplome (libelle) VALUES ('Licence'),('Master'),('BTS') ON DUPLICATE KEY UPDATE libelle=libelle;

INSERT INTO periode_evaluation (libelle, date_debut, date_fin, statut) VALUES
('Semestre 1 — 2025/26','2025-09-01','2026-01-31','C'),
('Semestre 2 — 2025/26','2026-02-01','2026-06-30','A'),
('Rattrapage — 2026','2026-07-01','2026-07-31','V')
ON DUPLICATE KEY UPDATE libelle=libelle;

INSERT INTO filiere (code_fili, libelle, diplome_id) VALUES
('INFO-L1','Licence 1 Informatique',1),
('INFO-L2','Licence 2 Informatique',1),
('INFO-L3','Licence 3 Informatique',1),
('GEST-L2','Licence 2 Gestion',1),
('GEST-L3','Licence 3 Gestion',1),
('FIN-M1','Master 1 Finance',2),
('DRT-L1','Licence 1 Droit',1),
('BTS-INFO','BTS Informatique',3)
ON DUPLICATE KEY UPDATE libelle=libelle;

INSERT INTO matiere (code_mati, nom_mati, volume_horaire) VALUES
('ALG-201','Algorithmes et Structures de donnees',60),
('COMPTA-301','Comptabilite Generale',45),
('MATH-101','Mathematiques Appliquees',90),
('ECO-201','Economie Generale',40),
('DRT-101','Introduction au Droit',50),
('PROG-102','Programmation PHP',75),
('BD-301','Bases de donnees',55),
('FIN-401','Finance Entreprise',60),
('MKTG-201','Marketing',40),
('ANG-101','Anglais des Affaires',30)
ON DUPLICATE KEY UPDATE nom_mati=nom_mati;

INSERT INTO enseignant (identifiant, nom, prenom, mail, sexe) VALUES
('ENS-001','Diallo','Mamadou','m.diallo@univ.ci','M'),
('ENS-002','Kone','Adjoua','a.kone@univ.ci','F'),
('ENS-003','Ouedraogo','Rasmane','r.ouedraogo@univ.ci','M'),
('ENS-004','Meite','Sylvain','s.meite@univ.ci','M'),
('ENS-005','Toure','Aicha','a.toure@univ.ci','F'),
('ENS-006','Coulibaly','Seydou','s.coulibaly@univ.ci','M'),
('ENS-007','Bah','Mariama','m.bah@univ.ci','F')
ON DUPLICATE KEY UPDATE nom=nom;

INSERT INTO enseignement (enseignant_id, matiere_id, dat_enseignement, volume_horaire) VALUES
(1,1,'2025-09-01',60),(1,6,'2025-09-01',40),
(2,2,'2025-09-01',45),(2,9,'2025-09-01',40),
(3,3,'2025-09-01',90),(4,5,'2025-09-01',50),
(5,4,'2025-09-01',40),(6,7,'2025-09-01',55),
(7,8,'2025-09-01',60)
ON DUPLICATE KEY UPDATE volume_horaire=volume_horaire;

INSERT INTO etudiant (identifiant, nom, prenom, mail, sexe, filiere_id) VALUES
('2024-INFO-L2-0001','Kouame','Aya','aya.kouame@etudiant.ci','F',2),
('2024-GEST-L3-0001','Traore','Ibrahim','ibrahim.traore@etudiant.ci','M',5),
('2024-FIN-M1-0001','Nguessan','Marie','marie.nguessan@etudiant.ci','F',6),
('2024-DRT-L1-0001','Bamba','Sekou','sekou.bamba@etudiant.ci','M',7),
('2024-INFO-L2-0002','Coulibaly','Fatou','fatou.coulibaly@etudiant.ci','F',2),
('2024-GEST-L2-0001','Diomande','Youssouf','youssouf.diomande@etudiant.ci','M',4),
('2024-INFO-L1-0001','Barry','Aminata','aminata.barry@etudiant.ci','F',1),
('2024-INFO-L1-0002','Keita','Moussa','moussa.keita@etudiant.ci','M',1),
('2024-GEST-L3-0002','Sanogo','Fatoumata','fatoumata.sanogo@etudiant.ci','F',5),
('2024-INFO-L3-0001','Diallo','Oumar','oumar.diallo@etudiant.ci','M',3),
('2024-FIN-M1-0002','Konate','Bintou','bintou.konate@etudiant.ci','F',6),
('2024-DRT-L1-0002','Sidibe','Lamine','lamine.sidibe@etudiant.ci','M',7),
('2024-INFO-L2-0003','Camara','Kadiatou','kadiatou.camara@etudiant.ci','F',2),
('2024-GEST-L2-0002','Sylla','Adama','adama.sylla@etudiant.ci','M',4),
('2024-INFO-L1-0003','Fofana','Mariama','mariama.fofana@etudiant.ci','F',1)
ON DUPLICATE KEY UPDATE nom=nom;

INSERT INTO horaire (enseignement_id, filiere_id, jour, heure_debut, heure_fin, date_periode, volume_horaire) VALUES
(1,2,'LUN','08:00','10:00',DATE_SUB(CURDATE(), INTERVAL 7 DAY),2),
(1,2,'LUN','08:00','10:00',DATE_SUB(CURDATE(), INTERVAL 14 DAY),2),
(2,1,'MAR','10:00','12:00',DATE_SUB(CURDATE(), INTERVAL 6 DAY),2),
(3,5,'MAR','08:00','10:00',DATE_SUB(CURDATE(), INTERVAL 5 DAY),2),
(5,3,'MER','08:00','10:00',DATE_SUB(CURDATE(), INTERVAL 4 DAY),2),
(4,7,'LUN','14:00','16:00',DATE_SUB(CURDATE(), INTERVAL 3 DAY),2),
(5,4,'JEU','14:00','16:00',DATE_SUB(CURDATE(), INTERVAL 2 DAY),2),
(7,3,'VEN','10:00','12:00',DATE_SUB(CURDATE(), INTERVAL 1 DAY),2),
(9,6,'JEU','08:00','10:00',CURDATE(),2);

INSERT INTO absence (etudiant_id, horaire_id, statut, motif, date_validation) VALUES
(1,1,'J','Maladie',DATE_SUB(CURDATE(),INTERVAL 6 DAY)),
(2,1,'I',NULL,NULL),
(5,1,'A',NULL,NULL),
(3,3,'J','Deuil familial',DATE_SUB(CURDATE(),INTERVAL 4 DAY)),
(4,4,'I',NULL,NULL),
(6,4,'A',NULL,NULL),
(7,5,'J','Raison medicale',DATE_SUB(CURDATE(),INTERVAL 3 DAY)),
(8,6,'A',NULL,NULL),
(9,7,'I',NULL,NULL),
(10,7,'A',NULL,NULL),
(11,8,'J','Maladie',DATE_SUB(CURDATE(),INTERVAL 1 DAY)),
(12,9,'A',NULL,NULL),
(13,2,'I',NULL,NULL),
(1,2,'A',NULL,NULL)
ON DUPLICATE KEY UPDATE statut=statut;

SET foreign_key_checks = 1;
