<?php
$pageTitle = 'Inscription des étudiants'; $currentPage = 'inscription';
require_once dirname(__DIR__,2).'/includes/header.php';
$pdo = getPDO(); $errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'add') {
        $ident = trim($_POST['identifiant'] ?? ''); $nom = trim($_POST['nom'] ?? '');
        $prenom = trim($_POST['prenom'] ?? ''); $mail = trim($_POST['mail'] ?? '');
        $sexe = $_POST['sexe'] ?? 'M'; $fil = $_POST['filiere_id'] ?: null;
        if (!$ident || !$nom || !$prenom || !$mail) $errors[] = 'Tous les champs sont obligatoires.';
        if (!filter_var($mail, FILTER_VALIDATE_EMAIL)) $errors[] = 'Email invalide.';
        if (empty($errors)) {
            try {
                $pdo->prepare("INSERT INTO etudiant (identifiant,nom,prenom,mail,sexe,filiere_id) VALUES (?,?,?,?,?,?)")
                    ->execute([$ident,$nom,$prenom,$mail,$sexe,$fil]);
                flash('Étudiant inscrit.'); redirect('/modules/saisie/inscription.php?tab=liste');
            } catch (Exception $e) { $errors[] = 'Identifiant ou email déjà utilisé.'; }
        }
    } elseif ($action === 'edit') {
        try {
            $pdo->prepare("UPDATE etudiant SET identifiant=?,nom=?,prenom=?,mail=?,sexe=?,filiere_id=? WHERE id=?")
                ->execute([$_POST['identifiant'],$_POST['nom'],$_POST['prenom'],$_POST['mail'],$_POST['sexe'],$_POST['filiere_id']?:(null),(int)$_POST['id']]);
            flash('Étudiant modifié.'); redirect('/modules/saisie/inscription.php?tab=liste');
        } catch (Exception $e) { $errors[] = 'Identifiant ou email déjà utilisé.'; }
    } elseif ($action === 'delete') {
        $pdo->prepare("DELETE FROM etudiant WHERE id=?")->execute([(int)$_POST['id']]);
        flash('Étudiant supprimé.'); redirect('/modules/saisie/inscription.php?tab=liste');
    } elseif ($action === 'import') {
        if (isset($_FILES['csvfile']) && $_FILES['csvfile']['error'] === 0) {
            $lines = file($_FILES['csvfile']['tmp_name']);
            $created = 0; $skipped = 0;
            foreach (array_slice($lines, 1) as $line) {
                $row = str_getcsv(trim($line));
                if (count($row) < 6) continue;
                [$ident,$nom,$prenom,$mail,$sexe,$codeFil] = $row;
                $fil = $pdo->prepare("SELECT id FROM filiere WHERE code_fili=?");
                $fil->execute([trim($codeFil)]); $fil_id = $fil->fetchColumn() ?: null;
                $ident = trim($ident); $mail = trim($mail);
                if (!$ident || !$mail) { $skipped++; continue; }
                try {
                    $pdo->prepare("INSERT INTO etudiant (identifiant,nom,prenom,mail,sexe,filiere_id) VALUES (?,?,?,?,?,?)")
                        ->execute([$ident,trim($nom),trim($prenom),$mail,trim($sexe),$fil_id]);
                    $created++;
                } catch (Exception $e) { $skipped++; }
            }
            flash("$created étudiant(s) importé(s). $skipped ignoré(s).");
            redirect('/modules/saisie/inscription.php?tab=liste');
        }
    }
}

$filieres = $pdo->query("SELECT * FROM filiere ORDER BY libelle")->fetchAll();
$filQ = $_GET['filiere'] ?? ''; $q = $_GET['q'] ?? ''; $tab = $_GET['tab'] ?? 'nouveau';

$sql = "SELECT e.*, f.libelle as filiere_lib, COUNT(a.id) as nb_abs
        FROM etudiant e LEFT JOIN filiere f ON f.id=e.filiere_id LEFT JOIN absence a ON a.etudiant_id=e.id
        WHERE 1=1" . ($filQ?" AND e.filiere_id=?":"") . ($q?" AND (e.nom LIKE ? OR e.prenom LIKE ? OR e.identifiant LIKE ?)":"") . " GROUP BY e.id ORDER BY e.nom";
$stmt = $pdo->prepare($sql); $params = [];
if ($filQ) $params[] = $filQ;
if ($q) { $params[] = "%$q%"; $params[] = "%$q%"; $params[] = "%$q%"; }
$stmt->execute($params); $etudiants = $stmt->fetchAll();

$edit = null;
if (isset($_GET['edit'])) { $s=$pdo->prepare("SELECT * FROM etudiant WHERE id=?"); $s->execute([(int)$_GET['edit']]); $edit=$s->fetch(); $tab='nouveau'; }
?>

<div class="tabs">
  <a href="?tab=nouveau" class="tab <?= $tab==='nouveau'?'active':'' ?>">Nouveau</a>
  <a href="?tab=liste" class="tab <?= $tab==='liste'?'active':'' ?>">Liste (<?= count($etudiants) ?>)</a>
  <a href="?tab=import" class="tab <?= $tab==='import'?'active':'' ?>">Import CSV</a>
</div>

<?php foreach ($errors as $err): ?><div class="alert alert-danger"><span>❌</span><div><?= e($err) ?></div></div><?php endforeach; ?>

<?php if ($tab === 'nouveau' || $edit): ?>
<div class="card">
  <div class="card-header"><div class="card-title"><?= $edit ? 'Modifier l\'étudiant' : 'Inscrire un nouvel étudiant' ?></div></div>
  <form method="post">
    <input type="hidden" name="action" value="<?= $edit ? 'edit' : 'add' ?>">
    <?php if ($edit): ?><input type="hidden" name="id" value="<?= $edit['id'] ?>"><?php endif; ?>
    <div class="form-grid">
      <div class="form-group"><label class="form-label">Identifiant</label><input type="text" name="identifiant" class="form-input" value="<?= e($edit['identifiant']??'') ?>" placeholder="ex: 2024-INFO-L2-0001" required></div>
      <div class="form-group"><label class="form-label">Filière</label>
        <select name="filiere_id" class="form-input"><option value="">— Sélectionner —</option>
          <?php foreach ($filieres as $f): ?><option value="<?= $f['id'] ?>" <?= ($edit['filiere_id']??'')==$f['id']?'selected':'' ?>><?= e($f['libelle']) ?></option><?php endforeach; ?>
        </select></div>
      <div class="form-group"><label class="form-label">Nom</label><input type="text" name="nom" class="form-input" value="<?= e($edit['nom']??'') ?>" required></div>
      <div class="form-group"><label class="form-label">Prénom</label><input type="text" name="prenom" class="form-input" value="<?= e($edit['prenom']??'') ?>" required></div>
      <div class="form-group"><label class="form-label">Email</label><input type="email" name="mail" class="form-input" value="<?= e($edit['mail']??'') ?>" required></div>
      <div class="form-group"><label class="form-label">Sexe</label>
        <select name="sexe" class="form-input"><option value="M" <?= ($edit['sexe']??'M')==='M'?'selected':'' ?>>Masculin</option><option value="F" <?= ($edit['sexe']??'')==='F'?'selected':'' ?>>Féminin</option></select></div>
    </div>
    <div class="form-footer">
      <?php if ($edit): ?><a href="<?= BASE_URL ?>/modules/saisie/inscription.php?tab=liste" class="btn btn-ghost">Annuler</a><?php endif; ?>
      <button type="submit" class="btn btn-primary"><?= $edit ? 'Enregistrer' : 'Inscrire l\'étudiant' ?></button>
    </div>
  </form>
</div>

<?php elseif ($tab === 'import'): ?>
<div class="card">
  <div class="card-header"><div class="card-title">Import CSV</div></div>
  <div style="padding:18px">
    <div class="alert alert-info"><span>ℹ️</span><div>Format CSV requis — colonnes : <code>identifiant, nom, prenom, mail, sexe (M/F), code_filiere</code><br>Ligne 1 = en-tête (ignorée).</div></div>
    <form method="post" enctype="multipart/form-data">
      <input type="hidden" name="action" value="import">
      <div style="display:flex;gap:10px;align-items:center">
        <input type="file" name="csvfile" accept=".csv" class="form-input" style="flex:1">
        <button type="submit" class="btn btn-primary">Importer</button>
      </div>
    </form>
  </div>
</div>

<?php else: ?>
<div class="card">
  <form method="get" class="search-bar">
    <input type="hidden" name="tab" value="liste">
    <input type="text" name="q" value="<?= e($q) ?>" class="form-input" placeholder="🔍  Rechercher..." style="flex:1;max-width:260px">
    <select name="filiere" class="form-input" style="width:auto" onchange="this.form.submit()">
      <option value="">Toutes les filières</option>
      <?php foreach ($filieres as $f): ?><option value="<?= $f['id'] ?>" <?= $filQ==$f['id']?'selected':'' ?>><?= e($f['libelle']) ?></option><?php endforeach; ?>
    </select>
    <button type="submit" class="btn btn-ghost btn-sm">Filtrer</button>
  </form>
  <table>
    <thead><tr><th>ID</th><th>Nom complet</th><th>Email</th><th>Filière</th><th>Absences</th><th>Actions</th></tr></thead>
    <tbody>
      <?php foreach ($etudiants as $e): ?>
      <tr>
        <td><span style="font-size:11px;color:var(--muted)"><?= e($e['identifiant']) ?></span></td>
        <td><div style="display:flex;align-items:center;gap:8px">
          <div class="avatar" style="width:26px;height:26px;background:var(--accent);font-size:9px"><?= strtoupper(substr($e['prenom'],0,1).substr($e['nom'],0,1)) ?></div>
          <strong><?= e($e['prenom'].' '.$e['nom']) ?></strong></div></td>
        <td style="color:var(--info);font-size:12px"><?= e($e['mail']) ?></td>
        <td><?= e($e['filiere_lib'] ?? '—') ?></td>
        <td><span style="font-weight:500;color:<?= $e['nb_abs']>5?'var(--danger)':($e['nb_abs']>2?'var(--warning)':'var(--success)') ?>"><?= $e['nb_abs'] ?></span></td>
        <td style="display:flex;gap:5px">
          <a href="?edit=<?= $e['id'] ?>" class="btn btn-ghost btn-sm">✏️</a>
          <form method="post" data-confirm="Supprimer <?= e($e['prenom'].' '.$e['nom']) ?> ?">
            <input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= $e['id'] ?>">
            <button type="submit" class="btn btn-ghost btn-sm" style="color:var(--danger)">✕</button>
          </form>
        </td>
      </tr>
      <?php endforeach; if (empty($etudiants)): ?>
      <tr><td colspan="6" style="text-align:center;padding:30px;color:var(--muted)">Aucun étudiant trouvé</td></tr>
      <?php endif; ?>
    </tbody>
  </table>
</div>
<?php endif; ?>

<?php require_once dirname(__DIR__,2).'/includes/footer.php'; ?>
