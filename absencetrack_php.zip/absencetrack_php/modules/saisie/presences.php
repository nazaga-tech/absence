<?php
$pageTitle = 'Saisie présences / absences'; $currentPage = 'presences';
require_once dirname(__DIR__,2).'/includes/header.php';
$pdo = getPDO();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['horaire_id'])) {
    $horId = (int)$_POST['horaire_id'];
    $hor = $pdo->prepare("SELECT filiere_id FROM horaire WHERE id=?"); $hor->execute([$horId]); $hor = $hor->fetch();
    if ($hor) {
        $etudiants = $pdo->prepare("SELECT id FROM etudiant WHERE filiere_id=?");
        $etudiants->execute([$hor['filiere_id']]); $etudiants = $etudiants->fetchAll(PDO::FETCH_COLUMN);
        $absents = $_POST['absents'] ?? [];
        $saved = 0;
        foreach ($etudiants as $eId) {
            if (in_array((string)$eId, $absents)) {
                $check = $pdo->prepare("SELECT id FROM absence WHERE etudiant_id=? AND horaire_id=?");
                $check->execute([$eId,$horId]);
                if (!$check->fetch()) {
                    $pdo->prepare("INSERT INTO absence (etudiant_id,horaire_id,statut) VALUES (?,?,'A')")->execute([$eId,$horId]);
                    $saved++;
                }
            } else {
                $pdo->prepare("DELETE FROM absence WHERE etudiant_id=? AND horaire_id=? AND statut='A'")->execute([$eId,$horId]);
            }
        }
        flash("Appel enregistré — $saved nouvelle(s) absence(s).");
        redirect('/modules/saisie/presences.php');
    }
}

$horaires = $pdo->query("
    SELECT h.id, h.date_periode, h.heure_debut, h.heure_fin, h.jour,
           m.nom_mati, CONCAT('Pr. ',en.prenom,' ',en.nom) as enseignant, f.libelle as filiere, f.id as filiere_id
    FROM horaire h
    JOIN enseignement ens ON h.enseignement_id = ens.id
    JOIN matiere m ON ens.matiere_id = m.id
    JOIN enseignant en ON ens.enseignant_id = en.id
    JOIN filiere f ON h.filiere_id = f.id
    ORDER BY h.date_periode DESC, h.heure_debut
")->fetchAll();

$horaire = null; $etudiants_seance = [];
$selHor = $_GET['horaire_id'] ?? null;
if ($selHor) {
    foreach ($horaires as $h) { if ($h['id'] == $selHor) { $horaire = $h; break; } }
    if ($horaire) {
        $etudiants_seance = $pdo->prepare("
            SELECT e.*, COALESCE(a.statut,NULL) as abs_statut, a.id as abs_id
            FROM etudiant e
            LEFT JOIN absence a ON a.etudiant_id=e.id AND a.horaire_id=?
            WHERE e.filiere_id=? ORDER BY e.nom
        "); $etudiants_seance->execute([$selHor,$horaire['filiere_id']]); $etudiants_seance = $etudiants_seance->fetchAll();
    }
}
?>

<div class="card" style="margin-bottom:18px">
  <div class="card-header"><div class="card-title">Sélectionner une séance</div></div>
  <form method="get" style="padding:18px;display:flex;gap:10px;align-items:flex-end">
    <div class="form-group" style="flex:1">
      <label class="form-label">Séance</label>
      <select name="horaire_id" class="form-input" onchange="this.form.submit()">
        <option value="">— Choisir une séance —</option>
        <?php foreach ($horaires as $h): ?>
        <option value="<?= $h['id'] ?>" <?= $selHor==$h['id']?'selected':'' ?>>
          <?= date('d/m/Y',strtotime($h['date_periode'])) ?> — <?= e($h['nom_mati']) ?> | <?= e($h['filiere']) ?> | <?= $h['heure_debut'] ?>–<?= $h['heure_fin'] ?>
        </option>
        <?php endforeach; ?>
      </select>
    </div>
    <button type="submit" class="btn btn-primary">Charger</button>
  </form>
</div>

<?php if ($horaire): ?>
<div class="card">
  <div class="card-header">
    <div>
      <div class="card-title">Feuille d'appel — <?= e($horaire['nom_mati']) ?></div>
      <div style="font-size:12px;color:var(--muted);margin-top:3px">
        <?= e($horaire['filiere']) ?> · <?= date('d/m/Y',strtotime($horaire['date_periode'])) ?> · <?= $horaire['heure_debut'] ?>–<?= $horaire['heure_fin'] ?>
      </div>
    </div>
    <span class="badge badge-info"><?= count($etudiants_seance) ?> étudiant(s)</span>
  </div>

  <form method="post">
    <input type="hidden" name="horaire_id" value="<?= $horaire['id'] ?>">
    <div style="padding:12px 18px;background:#fafaf9;border-bottom:1px solid var(--border);display:flex;gap:10px;align-items:center">
      <button type="button" onclick="document.querySelectorAll('.cb-absent').forEach(c=>{c.checked=true;highlightRow(c)})" class="btn btn-ghost btn-sm">Tous absents</button>
      <button type="button" onclick="document.querySelectorAll('.cb-absent').forEach(c=>{c.checked=false;highlightRow(c)})" class="btn btn-ghost btn-sm">Tous présents</button>
      <span style="font-size:12px;color:var(--muted);margin-left:auto" id="count-info">0 absent(s)</span>
    </div>
    <table>
      <thead><tr>
        <th style="width:44px"><input type="checkbox" onchange="toggleAll(this)"></th>
        <th>Étudiant</th><th>Identifiant</th><th>Statut actuel</th><th>Message</th>
      </tr></thead>
      <tbody>
        <?php foreach ($etudiants_seance as $e): $isAbsent = $e['abs_statut'] !== null; ?>
        <tr <?= $isAbsent?'class="appel-absent"':'' ?>>
          <td style="text-align:center">
            <input type="checkbox" name="absents[]" value="<?= $e['id'] ?>" class="cb-absent" <?= $isAbsent?'checked':'' ?>>
          </td>
          <td><div style="display:flex;align-items:center;gap:8px">
            <div class="avatar" style="width:26px;height:26px;background:<?= $isAbsent?'var(--danger)':'var(--accent2)' ?>;font-size:9px"><?= strtoupper(substr($e['prenom'],0,1).substr($e['nom'],0,1)) ?></div>
            <strong><?= e($e['prenom'].' '.$e['nom']) ?></strong></div></td>
          <td><span style="font-size:11px;color:var(--muted)"><?= e($e['identifiant']) ?></span></td>
          <td><?= $isAbsent ? badgeStatut($e['abs_statut']) : '<span class="badge badge-success">Présent</span>' ?></td>
          <td>
            <?php if ($isAbsent && $e['abs_id']): ?>
            <a href="<?= BASE_URL ?>/modules/saisie/message.php?absence_id=<?= $e['abs_id'] ?>" class="btn btn-warning btn-sm">✉ Message</a>
            <?php else: ?><span style="color:var(--muted);font-size:12px">—</span><?php endif; ?>
          </td>
        </tr>
        <?php endforeach; if (empty($etudiants_seance)): ?>
        <tr><td colspan="5" style="text-align:center;padding:30px;color:var(--muted)">Aucun étudiant dans cette filière</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
    <div class="form-footer">
      <button type="submit" class="btn btn-primary">💾 Enregistrer l'appel</button>
    </div>
  </form>
</div>
<?php endif; ?>

<?php require_once dirname(__DIR__,2).'/includes/footer.php'; ?>
