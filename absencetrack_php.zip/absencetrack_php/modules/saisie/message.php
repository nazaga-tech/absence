<?php
$pageTitle = 'Envoyer un message'; $currentPage = 'presences';
require_once dirname(__DIR__,2).'/includes/header.php';
$pdo = getPDO();

$absId = (int)($_GET['absence_id'] ?? 0);
$stmt = $pdo->prepare("
    SELECT a.*, et.prenom, et.nom, et.mail, m.nom_mati, h.date_periode
    FROM absence a
    JOIN etudiant et ON a.etudiant_id = et.id
    JOIN horaire h ON a.horaire_id = h.id
    JOIN enseignement ens ON h.enseignement_id = ens.id
    JOIN matiere m ON ens.matiere_id = m.id
    WHERE a.id = ?
"); $stmt->execute([$absId]); $abs = $stmt->fetch();
if (!$abs) { flash('Absence introuvable.','error'); redirect('/modules/saisie/presences.php'); }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $contenu = trim($_POST['contenu'] ?? '');
    if ($contenu) {
        $pdo->prepare("INSERT INTO message_absence (absence_id,contenu,envoye) VALUES (?,?,1)")->execute([$absId,$contenu]);
        flash('Message envoyé à '.$abs['prenom'].' '.$abs['nom'].'.');
        redirect('/modules/saisie/presences.php');
    }
}
$topbarActions = '<a href="'.BASE_URL.'/modules/saisie/presences.php" class="btn btn-ghost">← Retour</a>';
?>

<div class="card" style="max-width:560px">
  <div class="card-header"><div class="card-title">Message à l'étudiant absent</div></div>
  <div style="padding:18px;background:#fafaf9;border-bottom:1px solid var(--border)">
    <table style="font-size:13px;width:100%">
      <tr><td style="color:var(--muted);padding:4px 0;width:110px">Destinataire</td><td><strong><?= e($abs['prenom'].' '.$abs['nom']) ?></strong></td></tr>
      <tr><td style="color:var(--muted);padding:4px 0">Email</td><td style="color:var(--info)"><?= e($abs['mail']) ?></td></tr>
      <tr><td style="color:var(--muted);padding:4px 0">Absence</td><td><?= e($abs['nom_mati']) ?> — <?= date('d/m/Y',strtotime($abs['date_periode'])) ?></td></tr>
    </table>
  </div>
  <form method="post">
    <div class="form-grid-1">
      <div class="form-group">
        <label class="form-label">Contenu du message</label>
        <textarea id="contenu" name="contenu" class="form-input" rows="6" placeholder="Saisir le message..."></textarea>
      </div>
    </div>
    <div style="padding:0 18px 14px">
      <button type="button" class="btn btn-ghost btn-sm"
        onclick="prefillMessage('<?= e($abs['prenom']) ?>','<?= e($abs['nom_mati']) ?>','<?= date('d/m/Y',strtotime($abs['date_periode'])) ?>')">
        Utiliser le modèle
      </button>
    </div>
    <div class="form-footer">
      <a href="<?= BASE_URL ?>/modules/saisie/presences.php" class="btn btn-ghost">Annuler</a>
      <button type="submit" class="btn btn-primary">✉ Envoyer</button>
    </div>
  </form>
</div>

<?php require_once dirname(__DIR__,2).'/includes/footer.php'; ?>
