<?php
$pageTitle = 'Justification des absences'; $currentPage = 'justification';
require_once dirname(__DIR__,2).'/includes/header.php';
$pdo = getPDO();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    foreach ($_POST as $k => $v) {
        if (str_starts_with($k, 'statut_')) {
            $abId = (int)str_replace('statut_','',$k);
            $motif = trim($_POST['motif_'.$abId] ?? '');
            $dateVal = in_array($v,['J','I']) ? date('Y-m-d') : null;
            $pdo->prepare("UPDATE absence SET statut=?,motif=?,date_validation=? WHERE id=?")->execute([$v,$motif,$dateVal,$abId]);
        }
    }
    flash('Décisions enregistrées avec succès.');
    redirect('/modules/saisie/justification.php?statut='.($_POST['filtre'] ?? 'A'));
}

$filtre = $_GET['statut'] ?? 'A';
$filiere = $_GET['filiere'] ?? '';
$q = $_GET['q'] ?? '';

$where = "WHERE 1=1"; $params = [];
if ($filtre) { $where .= " AND a.statut=?"; $params[] = $filtre; }
if ($filiere) { $where .= " AND et.filiere_id=?"; $params[] = $filiere; }
if ($q) { $where .= " AND (et.nom LIKE ? OR et.prenom LIKE ?)"; $params[] = "%$q%"; $params[] = "%$q%"; }

$stmt = $pdo->prepare("
    SELECT a.id, a.statut, a.motif, a.date_validation,
           et.prenom, et.nom, f.libelle as filiere,
           m.nom_mati, CONCAT('Pr. ',en.prenom,' ',en.nom) as enseignant,
           h.date_periode
    FROM absence a
    JOIN etudiant et ON a.etudiant_id = et.id
    LEFT JOIN filiere f ON et.filiere_id = f.id
    JOIN horaire h ON a.horaire_id = h.id
    JOIN enseignement ens ON h.enseignement_id = ens.id
    JOIN matiere m ON ens.matiere_id = m.id
    JOIN enseignant en ON ens.enseignant_id = en.id
    $where ORDER BY a.created_at DESC
"); $stmt->execute($params); $absences = $stmt->fetchAll();

$counts = [
    'A' => $pdo->query("SELECT COUNT(*) FROM absence WHERE statut='A'")->fetchColumn(),
    'J' => $pdo->query("SELECT COUNT(*) FROM absence WHERE statut='J'")->fetchColumn(),
    'I' => $pdo->query("SELECT COUNT(*) FROM absence WHERE statut='I'")->fetchColumn(),
];
$filieres = $pdo->query("SELECT * FROM filiere ORDER BY libelle")->fetchAll();
?>

<div class="three-cols">
  <div class="stat-card"><div class="stat-label">En attente</div><div class="stat-value" style="color:var(--warning)"><?= $counts['A'] ?></div></div>
  <div class="stat-card"><div class="stat-label">Justifiées</div><div class="stat-value" style="color:var(--success)"><?= $counts['J'] ?></div></div>
  <div class="stat-card"><div class="stat-label">Injustifiées</div><div class="stat-value" style="color:var(--danger)"><?= $counts['I'] ?></div></div>
</div>

<div class="card">
  <div class="tabs">
    <a href="?statut=A" class="tab <?= $filtre==='A'?'active':'' ?>">En attente (<?= $counts['A'] ?>)</a>
    <a href="?statut=J" class="tab <?= $filtre==='J'?'active':'' ?>">Justifiées (<?= $counts['J'] ?>)</a>
    <a href="?statut=I" class="tab <?= $filtre==='I'?'active':'' ?>">Injustifiées (<?= $counts['I'] ?>)</a>
    <a href="?" class="tab <?= $filtre===''?'active':'' ?>">Toutes</a>
  </div>
  <form method="get" class="search-bar">
    <?php if ($filtre): ?><input type="hidden" name="statut" value="<?= e($filtre) ?>"><?php endif; ?>
    <input type="text" name="q" value="<?= e($q) ?>" class="form-input" placeholder="🔍  Rechercher..." style="flex:1;max-width:240px">
    <select name="filiere" class="form-input" style="width:auto" onchange="this.form.submit()">
      <option value="">Toutes les filières</option>
      <?php foreach ($filieres as $f): ?><option value="<?= $f['id'] ?>" <?= $filiere==$f['id']?'selected':'' ?>><?= e($f['libelle']) ?></option><?php endforeach; ?>
    </select>
    <button type="submit" class="btn btn-ghost btn-sm">Filtrer</button>
  </form>

  <form method="post">
    <input type="hidden" name="filtre" value="<?= e($filtre) ?>">
    <table>
      <thead><tr><th>Étudiant</th><th>Filière</th><th>Matière</th><th>Enseignant</th><th>Date</th><th>Décision</th><th>Motif</th></tr></thead>
      <tbody>
        <?php foreach ($absences as $ab): ?>
        <tr>
          <td><div style="display:flex;align-items:center;gap:8px">
            <div class="avatar" style="width:26px;height:26px;background:var(--accent);font-size:9px"><?= strtoupper(substr($ab['prenom'],0,1).substr($ab['nom'],0,1)) ?></div>
            <div><div style="font-weight:500;font-size:12px"><?= e($ab['prenom'].' '.$ab['nom']) ?></div>
            <div style="font-size:10px;color:var(--muted)">AB-<?= $ab['id'] ?></div></div></div></td>
          <td><span style="font-size:11px"><?= e($ab['filiere'] ?? '—') ?></span></td>
          <td style="font-size:12px"><?= e($ab['nom_mati']) ?></td>
          <td style="font-size:12px"><?= e($ab['enseignant']) ?></td>
          <td style="font-size:12px"><?= date('d/m/Y',strtotime($ab['date_periode'])) ?></td>
          <td>
            <select name="statut_<?= $ab['id'] ?>" class="form-input" style="width:120px;padding:5px 8px;font-size:12px">
              <option value="A" <?= $ab['statut']==='A'?'selected':'' ?>>En attente</option>
              <option value="J" <?= $ab['statut']==='J'?'selected':'' ?>>Justifiée</option>
              <option value="I" <?= $ab['statut']==='I'?'selected':'' ?>>Injustifiée</option>
            </select>
          </td>
          <td><input type="text" name="motif_<?= $ab['id'] ?>" value="<?= e($ab['motif']) ?>" class="form-input" style="width:140px;font-size:12px;padding:5px 8px" placeholder="Motif..."></td>
        </tr>
        <?php endforeach; if (empty($absences)): ?>
        <tr><td colspan="7" style="text-align:center;padding:36px;color:var(--muted)">Aucune absence dans cette catégorie</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
    <?php if (!empty($absences)): ?>
    <div class="form-footer">
      <span style="font-size:12px;color:var(--muted)"><?= count($absences) ?> absence(s) affichée(s)</span>
      <button type="submit" class="btn btn-primary">💾 Enregistrer les décisions</button>
    </div>
    <?php endif; ?>
  </form>
</div>

<?php require_once dirname(__DIR__,2).'/includes/footer.php'; ?>
