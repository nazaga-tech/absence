<?php
$pageTitle = 'Horaires'; $currentPage = 'horaires';
require_once dirname(__DIR__).'/includes/header.php';
$pdo = getPDO();

$weekOffset = (int)($_GET['week'] ?? 0);
$monday = new DateTime(); $monday->modify('monday this week'); $monday->modify("$weekOffset weeks");
$sunday = clone $monday; $sunday->modify('+6 days');
$weekStart = $monday->format('Y-m-d'); $weekEnd = $sunday->format('Y-m-d');

$horaires = $pdo->prepare("
    SELECT h.*,m.nom_mati,CONCAT('Pr. ',en.prenom,' ',en.nom) as enseignant,f.libelle as filiere,f.code_fili
    FROM horaire h JOIN enseignement ens ON h.enseignement_id=ens.id JOIN matiere m ON ens.matiere_id=m.id
    JOIN enseignant en ON ens.enseignant_id=en.id JOIN filiere f ON h.filiere_id=f.id
    WHERE h.date_periode BETWEEN ? AND ? ORDER BY h.heure_debut
"); $horaires->execute([$weekStart,$weekEnd]); $horaires = $horaires->fetchAll();

$planning = ['LUN'=>[],'MAR'=>[],'MER'=>[],'JEU'=>[],'VEN'=>[]];
foreach ($horaires as $h) { if (isset($planning[$h['jour']])) $planning[$h['jour']][] = $h; }
$joursLabels = ['LUN'=>'Lundi','MAR'=>'Mardi','MER'=>'Mercredi','JEU'=>'Jeudi','VEN'=>'Vendredi'];
$topbarActions = '<a href="?week='.($weekOffset-1).'" class="btn btn-ghost">◀ Préc.</a><a href="?week='.($weekOffset+1).'" class="btn btn-ghost">Suiv. ▶</a>';
?>
<div class="card">
  <div class="card-header">
    <div class="card-title">Planning du <?= $monday->format('d/m') ?> au <?= $sunday->format('d/m/Y') ?></div>
    <a href="?" class="btn btn-ghost btn-sm">Semaine actuelle</a>
  </div>
  <div style="padding:18px;overflow-x:auto">
    <table style="min-width:700px;table-layout:fixed">
      <thead><tr><th style="width:80px">Heure</th><?php foreach ($joursLabels as $l): ?><th><?= $l ?></th><?php endforeach; ?></tr></thead>
      <tbody>
        <?php foreach (['08:00','10:00','12:00','14:00','16:00','18:00'] as $slot): ?>
        <tr>
          <td style="color:var(--muted);font-size:12px;vertical-align:top;padding-top:10px"><?= $slot ?></td>
          <?php foreach (array_keys($joursLabels) as $j): ?>
          <td style="vertical-align:top;padding:4px">
            <?php foreach ($planning[$j] as $h): if (substr($h['heure_debut'],0,5)===$slot): ?>
            <div style="background:#eff6ff;border-radius:6px;padding:8px;border-left:3px solid #3b82f6;margin-bottom:4px">
              <div style="font-size:12px;font-weight:500"><?= e($h['nom_mati']) ?></div>
              <div style="font-size:11px;color:var(--muted)"><?= e($h['enseignant']) ?></div>
              <div style="font-size:11px;color:var(--muted)"><?= e($h['code_fili']) ?> · <?= substr($h['heure_debut'],0,5) ?>–<?= substr($h['heure_fin'],0,5) ?></div>
            </div>
            <?php endif; endforeach; ?>
          </td>
          <?php endforeach; ?>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php require_once dirname(__DIR__).'/includes/footer.php'; ?>
