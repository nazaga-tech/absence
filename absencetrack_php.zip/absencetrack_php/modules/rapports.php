<?php
$pageTitle = 'Rapports'; $currentPage = 'rapports';
require_once dirname(__DIR__).'/includes/header.php';
$pdo = getPDO();
$monthStart = date('Y-m-01');

$parFiliere = $pdo->query("SELECT f.libelle, COUNT(a.id) as nb FROM filiere f LEFT JOIN etudiant et ON et.filiere_id=f.id LEFT JOIN absence a ON a.etudiant_id=et.id AND DATE(a.created_at)>='$monthStart' GROUP BY f.id ORDER BY nb DESC")->fetchAll();
$parMatiere = $pdo->query("SELECT m.nom_mati, COUNT(a.id) as nb FROM matiere m LEFT JOIN enseignement ens ON ens.matiere_id=m.id LEFT JOIN horaire h ON h.enseignement_id=ens.id LEFT JOIN absence a ON a.horaire_id=h.id AND DATE(a.created_at)>='$monthStart' GROUP BY m.id ORDER BY nb DESC LIMIT 8")->fetchAll();
$top = $pdo->query("SELECT et.id,et.prenom,et.nom,f.libelle as filiere, COUNT(a.id) as nb_abs, SUM(a.statut='I') as nb_inj FROM etudiant et LEFT JOIN filiere f ON f.id=et.filiere_id LEFT JOIN absence a ON a.etudiant_id=et.id GROUP BY et.id ORDER BY nb_abs DESC LIMIT 10")->fetchAll();
$maxFil = $parFiliere[0]['nb'] ?? 1; $maxMat = $parMatiere[0]['nb'] ?? 1;
?>

<div class="two-cols">
  <div class="card">
    <div class="card-header"><div class="card-title">Absences par filière (ce mois)</div></div>
    <div style="padding:18px">
      <?php foreach ($parFiliere as $r): ?>
      <div style="margin-bottom:14px">
        <div style="display:flex;justify-content:space-between;margin-bottom:5px;font-size:13px"><span><?= e($r['libelle']) ?></span><strong><?= $r['nb'] ?></strong></div>
        <div class="progress-track" style="width:100%"><div class="progress-fill" style="width:<?= $maxFil>0?round($r['nb']/$maxFil*100):0 ?>%;background:var(--accent)"></div></div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
  <div class="card">
    <div class="card-header"><div class="card-title">Absences par matière (ce mois)</div></div>
    <div style="padding:18px">
      <?php foreach ($parMatiere as $r): ?>
      <div style="margin-bottom:14px">
        <div style="display:flex;justify-content:space-between;margin-bottom:5px;font-size:13px"><span><?= e($r['nom_mati']) ?></span><strong><?= $r['nb'] ?></strong></div>
        <div class="progress-track" style="width:100%"><div class="progress-fill" style="width:<?= $maxMat>0?round($r['nb']/$maxMat*100):0 ?>%;background:var(--info)"></div></div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</div>

<div class="card">
  <div class="card-header"><div class="card-title">Top 10 — Étudiants les plus absents</div></div>
  <table>
    <thead><tr><th>Rang</th><th>Étudiant</th><th>Filière</th><th>Total abs.</th><th>Injustifiées</th><th></th></tr></thead>
    <tbody>
      <?php foreach ($top as $i => $e): ?>
      <tr>
        <td><strong style="color:<?= $i===0?'var(--danger)':($i<3?'var(--warning)':'var(--muted)') ?>">#<?= $i+1 ?></strong></td>
        <td><div style="display:flex;align-items:center;gap:8px"><div class="avatar" style="width:26px;height:26px;background:var(--accent);font-size:9px"><?= strtoupper(substr($e['prenom'],0,1).substr($e['nom'],0,1)) ?></div><strong><?= e($e['prenom'].' '.$e['nom']) ?></strong></div></td>
        <td><?= e($e['filiere'] ?? '—') ?></td>
        <td><span style="font-weight:600;color:var(--danger)"><?= $e['nb_abs'] ?></span></td>
        <td><span class="badge badge-danger"><?= $e['nb_inj'] ?></span></td>
        <td><a href="<?= BASE_URL ?>/modules/saisie/inscription.php?tab=liste&q=<?= urlencode($e['nom']) ?>" class="btn btn-ghost btn-sm">Profil</a></td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>
<?php require_once dirname(__DIR__).'/includes/footer.php'; ?>
