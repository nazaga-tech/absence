<?php
$pageTitle = 'Liste des absences justifiées'; $currentPage = 'edition';
require_once dirname(__DIR__,2).'/includes/header.php';
$pdo = getPDO();

$filiere = $_GET['filiere'] ?? '';
$periode = $_GET['periode'] ?? '';
$etudiant = $_GET['etudiant'] ?? '';

$where = "WHERE a.statut='J'"; $params = [];
if ($filiere) { $where .= " AND et.filiere_id=?"; $params[] = $filiere; }
if ($etudiant) { $where .= " AND a.etudiant_id=?"; $params[] = $etudiant; }
if ($periode) {
    $p = $pdo->prepare("SELECT date_debut,date_fin FROM periode_evaluation WHERE id=?"); $p->execute([$periode]); $p=$p->fetch();
    if ($p) { $where .= " AND h.date_periode BETWEEN ? AND ?"; $params[] = $p['date_debut']; $params[] = $p['date_fin']; }
}

$stmt = $pdo->prepare("
    SELECT a.id, a.motif, a.date_validation,
           et.prenom, et.nom, et.identifiant, f.libelle as filiere,
           m.nom_mati, CONCAT('Pr. ',en.prenom,' ',en.nom) as enseignant,
           h.date_periode, h.volume_horaire
    FROM absence a
    JOIN etudiant et ON a.etudiant_id=et.id
    LEFT JOIN filiere f ON et.filiere_id=f.id
    JOIN horaire h ON a.horaire_id=h.id
    JOIN enseignement ens ON h.enseignement_id=ens.id
    JOIN matiere m ON ens.matiere_id=m.id
    JOIN enseignant en ON ens.enseignant_id=en.id
    $where ORDER BY h.date_periode DESC
"); $stmt->execute($params); $absences = $stmt->fetchAll();

$totalHeures = array_sum(array_column($absences,'volume_horaire'));
$etuConcernes = count(array_unique(array_map(fn($a)=>$a['identifiant'],$absences)));

$filieres  = $pdo->query("SELECT * FROM filiere ORDER BY libelle")->fetchAll();
$periodes  = $pdo->query("SELECT * FROM periode_evaluation ORDER BY date_debut DESC")->fetchAll();
$etudiants = $pdo->query("SELECT id,prenom,nom FROM etudiant ORDER BY nom")->fetchAll();

$topbarActions = '
  <button onclick="window.print()" class="btn btn-ghost no-print">🖨️ Imprimer</button>
';
?>

<div class="card no-print" style="margin-bottom:18px">
  <div class="card-header"><div class="card-title">Filtres</div></div>
  <form method="get">
    <div class="form-grid">
      <div class="form-group"><label class="form-label">Filière</label>
        <select name="filiere" class="form-input"><option value="">Toutes les filières</option>
          <?php foreach ($filieres as $f): ?><option value="<?= $f['id'] ?>" <?= $filiere==$f['id']?'selected':'' ?>><?= e($f['libelle']) ?></option><?php endforeach; ?>
        </select></div>
      <div class="form-group"><label class="form-label">Période d'évaluation</label>
        <select name="periode" class="form-input"><option value="">Toutes les périodes</option>
          <?php foreach ($periodes as $p): ?><option value="<?= $p['id'] ?>" <?= $periode==$p['id']?'selected':'' ?>><?= e($p['libelle']) ?></option><?php endforeach; ?>
        </select></div>
      <div class="form-group"><label class="form-label">Étudiant</label>
        <select name="etudiant" class="form-input"><option value="">Tous les étudiants</option>
          <?php foreach ($etudiants as $et): ?><option value="<?= $et['id'] ?>" <?= $etudiant==$et['id']?'selected':'' ?>><?= e($et['prenom'].' '.$et['nom']) ?></option><?php endforeach; ?>
        </select></div>
      <div class="form-group" style="display:flex;align-items:flex-end">
        <button type="submit" class="btn btn-primary" style="width:100%">Appliquer</button>
      </div>
    </div>
  </form>
</div>

<div class="three-cols no-print">
  <div class="stat-card"><div class="stat-label">Total absences justifiées</div><div class="stat-value" style="color:var(--success)"><?= count($absences) ?></div></div>
  <div class="stat-card"><div class="stat-label">Étudiants concernés</div><div class="stat-value" style="color:var(--info)"><?= $etuConcernes ?></div></div>
  <div class="stat-card"><div class="stat-label">Volume horaire total</div><div class="stat-value" style="color:var(--primary)"><?= $totalHeures ?>h</div></div>
</div>

<div class="card" id="print-area">
  <div class="card-header">
    <div class="card-title">Absences justifiées (<?= count($absences) ?>)</div>
    <span style="font-size:11px;color:var(--muted)">Édition du <?= date('d/m/Y à H:i') ?></span>
  </div>
  <table>
    <thead>
      <tr><th>#</th><th>Étudiant</th><th>Filière</th><th>Matière</th><th>Enseignant</th><th>Date cours</th><th>Vol. h.</th><th>Motif</th><th>Validé le</th></tr>
    </thead>
    <tbody>
      <?php foreach ($absences as $ab): ?>
      <tr>
        <td><span class="badge badge-gray" style="font-size:10px">AB-<?= $ab['id'] ?></span></td>
        <td><div style="display:flex;align-items:center;gap:7px">
          <div class="avatar" style="width:26px;height:26px;background:var(--success);font-size:9px"><?= strtoupper(substr($ab['prenom'],0,1).substr($ab['nom'],0,1)) ?></div>
          <div><div style="font-weight:500;font-size:12px"><?= e($ab['prenom'].' '.$ab['nom']) ?></div>
          <div style="font-size:10px;color:var(--muted)"><?= e($ab['identifiant']) ?></div></div></div></td>
        <td style="font-size:11px"><?= e($ab['filiere'] ?? '—') ?></td>
        <td style="font-size:12px"><?= e($ab['nom_mati']) ?></td>
        <td style="font-size:12px"><?= e($ab['enseignant']) ?></td>
        <td style="font-size:12px"><?= date('d/m/Y',strtotime($ab['date_periode'])) ?></td>
        <td style="text-align:center"><span class="badge badge-success"><?= $ab['volume_horaire'] ?>h</span></td>
        <td style="font-size:12px"><?= e($ab['motif'] ?: '—') ?></td>
        <td style="font-size:12px"><?= $ab['date_validation'] ? date('d/m/Y',strtotime($ab['date_validation'])) : '—' ?></td>
      </tr>
      <?php endforeach; if (empty($absences)): ?>
      <tr><td colspan="9" style="text-align:center;padding:40px;color:var(--muted)">
        <div style="font-size:32px;margin-bottom:10px">✅</div>
        Aucune absence justifiée pour ces critères
      </td></tr>
      <?php endif; ?>
    </tbody>
    <?php if (!empty($absences)): ?>
    <tfoot>
      <tr><td colspan="6" style="padding:10px 14px;font-size:12px">Total</td>
          <td style="padding:10px 14px;font-size:12px;text-align:center"><?= $totalHeures ?>h</td>
          <td colspan="2"></td></tr>
    </tfoot>
    <?php endif; ?>
  </table>
</div>

<?php require_once dirname(__DIR__,2).'/includes/footer.php'; ?>
