<?php
$pageTitle = 'Enseignants'; $currentPage = 'enseignants';
require_once dirname(__DIR__,2).'/includes/header.php';
$pdo = getPDO(); $errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $fields = ['identifiant','nom','prenom','mail','sexe'];
    $vals = array_map(fn($f) => trim($_POST[$f] ?? ''), $fields);
    if ($action === 'add') {
        if (in_array('', array_slice($vals,0,4))) $errors[] = 'Tous les champs sont obligatoires.';
        if (empty($errors)) {
            $pdo->prepare("INSERT INTO enseignant (identifiant,nom,prenom,mail,sexe) VALUES (?,?,?,?,?)")
                ->execute($vals);
            flash('Enseignant ajouté.'); redirect('/modules/parametrage/enseignants.php');
        }
    } elseif ($action === 'edit') {
        $vals[] = (int)$_POST['id'];
        $pdo->prepare("UPDATE enseignant SET identifiant=?,nom=?,prenom=?,mail=?,sexe=? WHERE id=?")->execute($vals);
        flash('Enseignant modifié.'); redirect('/modules/parametrage/enseignants.php');
    } elseif ($action === 'delete') {
        $pdo->prepare("DELETE FROM enseignant WHERE id=?")->execute([(int)$_POST['id']]);
        flash('Enseignant supprimé.'); redirect('/modules/parametrage/enseignants.php');
    }
}

$q = $_GET['q'] ?? '';
$sql = "SELECT en.*, COUNT(DISTINCT h.id) as nb_seances, COUNT(DISTINCT a.id) as nb_abs
        FROM enseignant en
        LEFT JOIN enseignement ens ON ens.enseignant_id = en.id
        LEFT JOIN horaire h ON h.enseignement_id = ens.id
        LEFT JOIN absence a ON a.horaire_id = h.id
        WHERE 1=1 " . ($q ? "AND (en.nom LIKE ? OR en.prenom LIKE ?)" : "") . "
        GROUP BY en.id ORDER BY en.nom";
$stmt = $pdo->prepare($sql);
$q ? $stmt->execute(["%$q%","%$q%"]) : $stmt->execute();
$enseignants = $stmt->fetchAll();

$edit = null;
if (isset($_GET['edit'])) { $s=$pdo->prepare("SELECT * FROM enseignant WHERE id=?"); $s->execute([(int)$_GET['edit']]); $edit=$s->fetch(); }
?>
<div class="two-cols" style="align-items:start">
  <div class="card">
    <div class="card-header"><div class="card-title"><?= $edit ? 'Modifier' : 'Ajouter un enseignant' ?></div></div>
    <?php foreach ($errors as $err): ?><div class="alert alert-danger" style="margin:14px 18px 0"><span>❌</span><div><?= e($err) ?></div></div><?php endforeach; ?>
    <form method="post">
      <input type="hidden" name="action" value="<?= $edit ? 'edit' : 'add' ?>">
      <?php if ($edit): ?><input type="hidden" name="id" value="<?= $edit['id'] ?>"><?php endif; ?>
      <div class="form-grid">
        <div class="form-group"><label class="form-label">Identifiant</label><input type="text" name="identifiant" class="form-input" value="<?= e($edit['identifiant']??'') ?>" required></div>
        <div class="form-group"><label class="form-label">Sexe</label>
          <select name="sexe" class="form-input">
            <option value="M" <?= ($edit['sexe']??'M')==='M'?'selected':'' ?>>Masculin</option>
            <option value="F" <?= ($edit['sexe']??'')==='F'?'selected':'' ?>>Féminin</option>
          </select></div>
        <div class="form-group"><label class="form-label">Nom</label><input type="text" name="nom" class="form-input" value="<?= e($edit['nom']??'') ?>" required></div>
        <div class="form-group"><label class="form-label">Prénom</label><input type="text" name="prenom" class="form-input" value="<?= e($edit['prenom']??'') ?>" required></div>
        <div class="form-group full"><label class="form-label">Email</label><input type="email" name="mail" class="form-input" value="<?= e($edit['mail']??'') ?>" required></div>
      </div>
      <div class="form-footer">
        <?php if ($edit): ?><a href="<?= BASE_URL ?>/modules/parametrage/enseignants.php" class="btn btn-ghost">Annuler</a><?php endif; ?>
        <button type="submit" class="btn btn-primary"><?= $edit ? 'Enregistrer' : '+ Ajouter' ?></button>
      </div>
    </form>
  </div>
  <div class="card">
    <div class="card-header">
      <div class="card-title">Enseignants (<?= count($enseignants) ?>)</div>
      <form method="get" style="display:flex;gap:6px">
        <input type="text" name="q" value="<?= e($q) ?>" class="form-input" placeholder="Rechercher..." style="width:160px">
        <button type="submit" class="btn btn-ghost btn-sm">🔍</button>
      </form>
    </div>
    <table>
      <thead><tr><th>ID</th><th>Nom complet</th><th>Email</th><th>Séances</th><th>Absences</th><th></th></tr></thead>
      <tbody>
        <?php foreach ($enseignants as $en): ?>
        <tr>
          <td><span style="font-size:11px;color:var(--muted)"><?= e($en['identifiant']) ?></span></td>
          <td><div style="display:flex;align-items:center;gap:8px">
            <div class="avatar" style="width:28px;height:28px;background:var(--accent2);font-size:10px"><?= strtoupper(substr($en['prenom'],0,1).substr($en['nom'],0,1)) ?></div>
            <strong>Pr. <?= e($en['prenom'].' '.$en['nom']) ?></strong></div></td>
          <td style="color:var(--info);font-size:12px"><?= e($en['mail']) ?></td>
          <td><?= $en['nb_seances'] ?></td>
          <td><span style="font-weight:500;color:<?= $en['nb_abs']>10?'var(--danger)':($en['nb_abs']>5?'var(--warning)':'var(--success)') ?>"><?= $en['nb_abs'] ?></span></td>
          <td style="display:flex;gap:5px">
            <a href="?edit=<?= $en['id'] ?><?= $q?"&q=".urlencode($q):'' ?>" class="btn btn-ghost btn-sm">✏️</a>
            <form method="post" data-confirm="Supprimer ?">
              <input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= $en['id'] ?>">
              <button type="submit" class="btn btn-ghost btn-sm" style="color:var(--danger)">✕</button>
            </form>
          </td>
        </tr>
        <?php endforeach; if (empty($enseignants)): ?>
        <tr><td colspan="6" style="text-align:center;padding:30px;color:var(--muted)">Aucun enseignant</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>
<?php require_once dirname(__DIR__,2).'/includes/footer.php'; ?>
