<?php
$pageTitle = 'Matières'; $currentPage = 'matieres';
require_once dirname(__DIR__,2).'/includes/header.php';
$pdo = getPDO(); $errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    if ($action === 'add') {
        $code = trim($_POST['code_mati'] ?? '');
        $nom  = trim($_POST['nom_mati'] ?? '');
        $vol  = (int)($_POST['volume_horaire'] ?? 0);
        if (!$code || !$nom) $errors[] = 'Code et nom obligatoires.';
        if (empty($errors)) {
            $pdo->prepare("INSERT INTO matiere (code_mati,nom_mati,volume_horaire) VALUES (?,?,?)")
                ->execute([$code,$nom,$vol]);
            flash('Matière ajoutée.'); redirect('/modules/parametrage/matieres.php');
        }
    } elseif ($action === 'edit') {
        $pdo->prepare("UPDATE matiere SET code_mati=?,nom_mati=?,volume_horaire=? WHERE id=?")
            ->execute([$_POST['code_mati'],$_POST['nom_mati'],(int)$_POST['volume_horaire'],(int)$_POST['id']]);
        flash('Matière modifiée.'); redirect('/modules/parametrage/matieres.php');
    } elseif ($action === 'delete') {
        $pdo->prepare("DELETE FROM matiere WHERE id=?")->execute([(int)$_POST['id']]);
        flash('Matière supprimée.'); redirect('/modules/parametrage/matieres.php');
    }
}

$matieres = $pdo->query("
    SELECT m.*,
           COUNT(DISTINCT ens.enseignant_id) as nb_ens,
           COUNT(DISTINCT a.id) as nb_abs
    FROM matiere m
    LEFT JOIN enseignement ens ON ens.matiere_id = m.id
    LEFT JOIN horaire h ON h.enseignement_id = ens.id
    LEFT JOIN absence a ON a.horaire_id = h.id
    GROUP BY m.id ORDER BY m.nom_mati
")->fetchAll();
$edit = null;
if (isset($_GET['edit'])) { $s=$pdo->prepare("SELECT * FROM matiere WHERE id=?"); $s->execute([(int)$_GET['edit']]); $edit=$s->fetch(); }
?>
<div class="two-cols" style="align-items:start">
  <div class="card">
    <div class="card-header"><div class="card-title"><?= $edit ? 'Modifier la matière' : 'Ajouter une matière' ?></div></div>
    <form method="post">
      <input type="hidden" name="action" value="<?= $edit ? 'edit' : 'add' ?>">
      <?php if ($edit): ?><input type="hidden" name="id" value="<?= $edit['id'] ?>"><?php endif; ?>
      <div class="form-grid-1">
        <div class="form-group"><label class="form-label">Code matière</label>
          <input type="text" name="code_mati" class="form-input" value="<?= e($edit['code_mati']??'') ?>" placeholder="ex: MATH-101" required></div>
        <div class="form-group"><label class="form-label">Nom de la matière</label>
          <input type="text" name="nom_mati" class="form-input" value="<?= e($edit['nom_mati']??'') ?>" required></div>
        <div class="form-group"><label class="form-label">Volume horaire (h)</label>
          <input type="number" name="volume_horaire" class="form-input" value="<?= e($edit['volume_horaire']??'') ?>" min="0"></div>
      </div>
      <div class="form-footer">
        <?php if ($edit): ?><a href="<?= BASE_URL ?>/modules/parametrage/matieres.php" class="btn btn-ghost">Annuler</a><?php endif; ?>
        <button type="submit" class="btn btn-primary"><?= $edit ? 'Enregistrer' : '+ Ajouter' ?></button>
      </div>
    </form>
  </div>
  <div class="card">
    <div class="card-header"><div class="card-title">Matières (<?= count($matieres) ?>)</div></div>
    <table>
      <thead><tr><th>Code</th><th>Nom</th><th>Vol. h.</th><th>Enseignants</th><th>Absences</th><th></th></tr></thead>
      <tbody>
        <?php foreach ($matieres as $m): ?>
        <tr>
          <td><span class="badge badge-info"><?= e($m['code_mati']) ?></span></td>
          <td><strong><?= e($m['nom_mati']) ?></strong></td>
          <td><?= $m['volume_horaire'] ?>h</td>
          <td><?= $m['nb_ens'] ?></td>
          <td><span style="font-weight:500;color:<?= $m['nb_abs']>10?'var(--danger)':($m['nb_abs']>5?'var(--warning)':'var(--success)') ?>"><?= $m['nb_abs'] ?></span></td>
          <td style="display:flex;gap:5px">
            <a href="?edit=<?= $m['id'] ?>" class="btn btn-ghost btn-sm">✏️</a>
            <form method="post" data-confirm="Supprimer <?= e($m['nom_mati']) ?> ?">
              <input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= $m['id'] ?>">
              <button type="submit" class="btn btn-ghost btn-sm" style="color:var(--danger)">✕</button>
            </form>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php require_once dirname(__DIR__,2).'/includes/footer.php'; ?>
