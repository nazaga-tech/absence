<?php
$pageTitle = 'Filières'; $currentPage = 'filieres';
require_once dirname(__DIR__,2).'/includes/header.php';
$pdo = getPDO(); $errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    if ($action === 'add') {
        $code = trim($_POST['code_fili'] ?? ''); $lib = trim($_POST['libelle'] ?? ''); $dip = $_POST['diplome_id'] ?: null;
        if (!$code || !$lib) $errors[] = 'Code et libellé obligatoires.';
        if (empty($errors)) { $pdo->prepare("INSERT INTO filiere (code_fili,libelle,diplome_id) VALUES (?,?,?)")->execute([$code,$lib,$dip]); flash('Filière ajoutée.'); redirect('/modules/parametrage/filieres.php'); }
    } elseif ($action === 'edit') {
        $pdo->prepare("UPDATE filiere SET code_fili=?,libelle=?,diplome_id=? WHERE id=?")->execute([$_POST['code_fili'],$_POST['libelle'],$_POST['diplome_id']?:(null),(int)$_POST['id']]);
        flash('Filière modifiée.'); redirect('/modules/parametrage/filieres.php');
    } elseif ($action === 'delete') {
        $pdo->prepare("DELETE FROM filiere WHERE id=?")->execute([(int)$_POST['id']]); flash('Filière supprimée.'); redirect('/modules/parametrage/filieres.php');
    }
}

$filieres = $pdo->query("SELECT f.*,d.libelle as diplome_lib, COUNT(DISTINCT e.id) as nb_etu, COUNT(DISTINCT a.id) as nb_abs FROM filiere f LEFT JOIN diplome d ON d.id=f.diplome_id LEFT JOIN etudiant e ON e.filiere_id=f.id LEFT JOIN horaire h ON h.filiere_id=f.id LEFT JOIN absence a ON a.horaire_id=h.id GROUP BY f.id ORDER BY f.libelle")->fetchAll();
$diplomes = $pdo->query("SELECT * FROM diplome ORDER BY libelle")->fetchAll();
$edit = null;
if (isset($_GET['edit'])) { $s=$pdo->prepare("SELECT * FROM filiere WHERE id=?"); $s->execute([(int)$_GET['edit']]); $edit=$s->fetch(); }
?>
<div class="two-cols" style="align-items:start">
  <div class="card">
    <div class="card-header"><div class="card-title"><?= $edit ? 'Modifier la filière' : 'Ajouter une filière' ?></div></div>
    <form method="post">
      <input type="hidden" name="action" value="<?= $edit ? 'edit' : 'add' ?>">
      <?php if ($edit): ?><input type="hidden" name="id" value="<?= $edit['id'] ?>"><?php endif; ?>
      <div class="form-grid-1">
        <div class="form-group"><label class="form-label">Code filière</label><input type="text" name="code_fili" class="form-input" value="<?= e($edit['code_fili']??'') ?>" placeholder="ex: INFO-L2" required></div>
        <div class="form-group"><label class="form-label">Libellé</label><input type="text" name="libelle" class="form-input" value="<?= e($edit['libelle']??'') ?>" required></div>
        <div class="form-group"><label class="form-label">Diplôme</label>
          <select name="diplome_id" class="form-input"><option value="">— Sélectionner —</option>
            <?php foreach ($diplomes as $d): ?><option value="<?= $d['id'] ?>" <?= ($edit['diplome_id']??'')==$d['id']?'selected':'' ?>><?= e($d['libelle']) ?></option><?php endforeach; ?>
          </select></div>
      </div>
      <div class="form-footer">
        <?php if ($edit): ?><a href="<?= BASE_URL ?>/modules/parametrage/filieres.php" class="btn btn-ghost">Annuler</a><?php endif; ?>
        <button type="submit" class="btn btn-primary"><?= $edit ? 'Enregistrer' : '+ Ajouter' ?></button>
      </div>
    </form>
  </div>
  <div class="card">
    <div class="card-header"><div class="card-title">Filières (<?= count($filieres) ?>)</div></div>
    <table>
      <thead><tr><th>Code</th><th>Libellé</th><th>Diplôme</th><th>Étudiants</th><th>Absences</th><th></th></tr></thead>
      <tbody>
        <?php foreach ($filieres as $f): ?>
        <tr>
          <td><span class="badge badge-info"><?= e($f['code_fili']) ?></span></td>
          <td><strong><?= e($f['libelle']) ?></strong></td>
          <td><?= e($f['diplome_lib'] ?? '—') ?></td>
          <td><?= $f['nb_etu'] ?></td>
          <td><?= $f['nb_abs'] ?></td>
          <td style="display:flex;gap:5px">
            <a href="?edit=<?= $f['id'] ?>" class="btn btn-ghost btn-sm">✏️</a>
            <form method="post" data-confirm="Supprimer cette filière ?">
              <input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= $f['id'] ?>">
              <button type="submit" class="btn btn-ghost btn-sm" style="color:var(--danger)">✕</button>
            </form>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php require_once dirname(__DIR__,2).'/includes/footer.php'; ?>
