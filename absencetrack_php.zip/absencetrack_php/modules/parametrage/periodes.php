<?php
$pageTitle = 'Périodes d\'évaluation'; $currentPage = 'periodes';
require_once dirname(__DIR__,2).'/includes/header.php';
$pdo = getPDO();
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    if ($action === 'add') {
        $lib = trim($_POST['libelle'] ?? '');
        $dd  = $_POST['date_debut'] ?? '';
        $df  = $_POST['date_fin'] ?? '';
        $st  = $_POST['statut'] ?? 'V';
        if (!$lib) $errors[] = 'Le libellé est obligatoire.';
        if (!$dd || !$df) $errors[] = 'Les dates sont obligatoires.';
        if (empty($errors)) {
            $pdo->prepare("INSERT INTO periode_evaluation (libelle,date_debut,date_fin,statut) VALUES (?,?,?,?)")
                ->execute([$lib,$dd,$df,$st]);
            flash('Période ajoutée avec succès.');
            redirect('/modules/parametrage/periodes.php');
        }
    } elseif ($action === 'edit') {
        $id = (int)$_POST['id'];
        $pdo->prepare("UPDATE periode_evaluation SET libelle=?,date_debut=?,date_fin=?,statut=? WHERE id=?")
            ->execute([$_POST['libelle'],$_POST['date_debut'],$_POST['date_fin'],$_POST['statut'],$id]);
        flash('Période modifiée.');
        redirect('/modules/parametrage/periodes.php');
    } elseif ($action === 'delete') {
        $pdo->prepare("DELETE FROM periode_evaluation WHERE id=?")->execute([(int)$_POST['id']]);
        flash('Période supprimée.');
        redirect('/modules/parametrage/periodes.php');
    }
}

$periodes = $pdo->query("SELECT * FROM periode_evaluation ORDER BY date_debut DESC")->fetchAll();
$edit = null;
if (isset($_GET['edit'])) {
    $edit = $pdo->prepare("SELECT * FROM periode_evaluation WHERE id=?");
    $edit->execute([(int)$_GET['edit']]); $edit = $edit->fetch();
}
$topbarActions = '';
?>

<div class="two-cols" style="align-items:start">
  <div class="card">
    <div class="card-header"><div class="card-title"><?= $edit ? 'Modifier la période' : 'Nouvelle période' ?></div></div>
    <?php foreach ($errors as $err): ?>
      <div class="alert alert-danger" style="margin:14px 18px 0"><span>❌</span><div><?= e($err) ?></div></div>
    <?php endforeach; ?>
    <form method="post">
      <input type="hidden" name="action" value="<?= $edit ? 'edit' : 'add' ?>">
      <?php if ($edit): ?><input type="hidden" name="id" value="<?= $edit['id'] ?>"><?php endif; ?>
      <div class="form-grid-1">
        <div class="form-group"><label class="form-label">Libellé</label>
          <input type="text" name="libelle" class="form-input" value="<?= e($edit['libelle'] ?? '') ?>" placeholder="ex: Semestre 1 — 2025/26" required></div>
        <div class="form-group"><label class="form-label">Date de début</label>
          <input type="date" name="date_debut" class="form-input" value="<?= e($edit['date_debut'] ?? '') ?>" required></div>
        <div class="form-group"><label class="form-label">Date de fin</label>
          <input type="date" name="date_fin" class="form-input" value="<?= e($edit['date_fin'] ?? '') ?>" required></div>
        <div class="form-group"><label class="form-label">Statut</label>
          <select name="statut" class="form-input">
            <option value="V" <?= ($edit['statut']??'V')==='V'?'selected':'' ?>>À venir</option>
            <option value="A" <?= ($edit['statut']??'')==='A'?'selected':'' ?>>Active</option>
            <option value="C" <?= ($edit['statut']??'')==='C'?'selected':'' ?>>Clôturée</option>
          </select></div>
      </div>
      <div class="form-footer">
        <?php if ($edit): ?>
          <a href="<?= BASE_URL ?>/modules/parametrage/periodes.php" class="btn btn-ghost">Annuler</a>
        <?php endif; ?>
        <button type="submit" class="btn btn-primary"><?= $edit ? 'Enregistrer' : '+ Ajouter' ?></button>
      </div>
    </form>
  </div>

  <div class="card">
    <div class="card-header"><div class="card-title">Périodes (<?= count($periodes) ?>)</div></div>
    <table>
      <thead><tr><th>Libellé</th><th>Début</th><th>Fin</th><th>Statut</th><th>Actions</th></tr></thead>
      <tbody>
        <?php foreach ($periodes as $p): ?>
        <tr>
          <td><strong><?= e($p['libelle']) ?></strong></td>
          <td><?= date('d/m/Y',strtotime($p['date_debut'])) ?></td>
          <td><?= date('d/m/Y',strtotime($p['date_fin'])) ?></td>
          <td><?= badgePeriode($p['statut']) ?></td>
          <td style="display:flex;gap:5px">
            <a href="?edit=<?= $p['id'] ?>" class="btn btn-ghost btn-sm">✏️</a>
            <form method="post" data-confirm="Supprimer cette période ?">
              <input type="hidden" name="action" value="delete">
              <input type="hidden" name="id" value="<?= $p['id'] ?>">
              <button type="submit" class="btn btn-ghost btn-sm" style="color:var(--danger)">✕</button>
            </form>
          </td>
        </tr>
        <?php endforeach; if (empty($periodes)): ?>
        <tr><td colspan="5" style="text-align:center;padding:30px;color:var(--muted)">Aucune période définie</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>
<?php require_once dirname(__DIR__,2).'/includes/footer.php'; ?>
