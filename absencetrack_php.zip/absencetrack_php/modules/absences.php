<?php
$pageTitle = 'Absences'; $currentPage = 'absences';
require_once dirname(__DIR__).'/includes/header.php';
$pdo = getPDO();

$statut = $_GET['statut'] ?? ''; $filiere = $_GET['filiere'] ?? '';
$matiere = $_GET['matiere'] ?? ''; $q = $_GET['q'] ?? ''; $dateF = $_GET['date'] ?? '';

$where = "WHERE 1=1"; $params = [];
if ($statut) { $where .= " AND a.statut=?"; $params[] = $statut; }
if ($filiere) { $where .= " AND et.filiere_id=?"; $params[] = $filiere; }
if ($matiere) { $where .= " AND ens.matiere_id=?"; $params[] = $matiere; }
if ($q) { $where .= " AND (et.nom LIKE ? OR et.prenom LIKE ?)"; $params[] = "%$q%"; $params[] = "%$q%"; }
if ($dateF) { $where .= " AND h.date_periode=?"; $params[] = $dateF; }

$stmt = $pdo->prepare("
    SELECT a.id, a.statut, a.created_at,
           et.prenom, et.nom, f.libelle as filiere,
           m.nom_mati, CONCAT('Pr. ',en.prenom,' ',en.nom) as enseignant,
           h.date_periode, h.volume_horaire
    FROM absence a
    JOIN etudiant et ON a.etudiant_id=et.id
    LEFT JOIN filiere f ON et.filiere_id=f.id
    JOIN horaire h ON a.horaire_id=h.id
    JOIN enseignement ens ON h.enseignement_id=ens.id
    JOIN matiere m ON ens.matiere_id=m.id
    JOIN enseignant en ON ens.enseignant_id=en.id
    $where ORDER BY a.created_at DESC
"); $stmt->execute($params); $absences = $stmt->fetchAll();

$counts = [
    'total' => $pdo->query("SELECT COUNT(*) FROM absence")->fetchColumn(),
    'A'     => $pdo->query("SELECT COUNT(*) FROM absence WHERE statut='A'")->fetchColumn(),
    'J'     => $pdo->query("SELECT COUNT(*) FROM absence WHERE statut='J'")->fetchColumn(),
    'I'     => $pdo->query("SELECT COUNT(*) FROM absence WHERE statut='I'")->fetchColumn(),
];
$filieres = $pdo->query("SELECT * FROM filiere ORDER BY libelle")->fetchAll();
$matieres = $pdo->query("SELECT * FROM matiere ORDER BY nom_mati")->fetchAll();
$topbarActions = '<a href="'.BASE_URL.'/modules/saisie/presences.php" class="btn btn-primary">+ Signaler absence</a>';
?>

<div class="card">
  <div class="tabs">
    <a href="?" class="tab <?= $statut===''?'active':'' ?>">Toutes (<?= $counts['total'] ?>)</a>
    <a href="?statut=A" class="tab <?= $statut==='A'?'active':'' ?>">En attente (<?= $counts['A'] ?>)</a>
    <a href="?statut=J" class="tab <?= $statut==='J'?'active':'' ?>">Justifiées (<?= $counts['J'] ?>)</a>
    <a href="?statut=I" class="tab <?= $statut==='I'?'active':'' ?>">Injustifiées (<?= $counts['I'] ?>)</a>
  </div>
  <form method="get" class="search-bar">
    <?php if ($statut): ?><input type="hidden" name="statut" value="<?= e($statut) ?>"><?php endif; ?>
    <input type="text" name="q" value="<?= e($q) ?>" class="form-input" placeholder="🔍  Rechercher..." style="flex:1;max-width:240px">
    <select name="filiere" class="form-input" style="width:auto" onchange="this.form.submit()">
      <option value="">Toutes les filières</option>
      <?php foreach ($filieres as $f): ?><option value="<?= $f['id'] ?>" <?= $filiere==$f['id']?'selected':'' ?>><?= e($f['libelle']) ?></option><?php endforeach; ?>
    </select>
    <select name="matiere" class="form-input" style="width:auto" onchange="this.form.submit()">
      <option value="">Toutes les matières</option>
      <?php foreach ($matieres as $m): ?><option value="<?= $m['id'] ?>" <?= $matiere==$m['id']?'selected':'' ?>><?= e($m['nom_mati']) ?></option><?php endforeach; ?>
    </select>
    <input type="date" name="date" value="<?= e($dateF) ?>" class="form-input" style="width:auto" onchange="this.form.submit()">
    <button type="submit" class="btn btn-ghost btn-sm">Filtrer</button>
  </form>
  <table>
    <thead><tr><th>#</th><th>Étudiant</th><th>Filière</th><th>Matière</th><th>Enseignant</th><th>Date</th><th>Statut</th><th>Actions</th></tr></thead>
    <tbody>
      <?php foreach ($absences as $ab): ?>
      <tr>
        <td><span class="badge badge-gray" style="font-size:10px">AB-<?= $ab['id'] ?></span></td>
        <td><div style="font-weight:500"><?= e($ab['prenom'].' '.$ab['nom']) ?></div></td>
        <td><span style="font-size:11px;color:var(--muted)"><?= e($ab['filiere'] ?? '—') ?></span></td>
        <td><?= e($ab['nom_mati']) ?></td>
        <td><?= e($ab['enseignant']) ?></td>
        <td><?= date('d/m/Y',strtotime($ab['date_periode'])) ?></td>
        <td><?= badgeStatut($ab['statut']) ?></td>
        <td><a href="<?= BASE_URL ?>/modules/saisie/justification.php?statut=" class="btn btn-ghost btn-sm">Traiter</a></td>
      </tr>
      <?php endforeach; if (empty($absences)): ?>
      <tr><td colspan="8" style="text-align:center;padding:36px;color:var(--muted)">Aucune absence trouvée</td></tr>
      <?php endif; ?>
    </tbody>
  </table>
</div>
<?php require_once dirname(__DIR__).'/includes/footer.php'; ?>
