// Confirmation suppression
document.querySelectorAll('form[data-confirm]').forEach(f => {
  f.addEventListener('submit', e => {
    if (!confirm(f.dataset.confirm)) e.preventDefault();
  });
});

// Tabs dynamiques
function showTab(id, el) {
  document.querySelectorAll('[data-tab]').forEach(t => t.style.display = 'none');
  document.querySelectorAll('.tab[onclick]').forEach(t => t.classList.remove('active'));
  const target = document.querySelector('[data-tab="' + id + '"]');
  if (target) target.style.display = 'block';
  el.classList.add('active');
}

// Feuille d'appel
function updateCount() {
  const n = document.querySelectorAll('.cb-absent:checked').length;
  const el = document.getElementById('count-info');
  if (el) el.textContent = n + ' absent(s) sélectionné(s)';
}
function highlightRow(cb) {
  cb.closest('tr').className = cb.checked ? 'appel-absent' : '';
  updateCount();
}
function toggleAll(master) {
  document.querySelectorAll('.cb-absent').forEach(cb => { cb.checked = master.checked; highlightRow(cb); });
}
document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('.cb-absent').forEach(cb => cb.addEventListener('change', () => highlightRow(cb)));
  updateCount();
});

// Pré-remplir message
function prefillMessage(prenom, matiere, date) {
  const ta = document.getElementById('contenu');
  if (ta) ta.value = `Bonjour ${prenom},\n\nNous avons constaté votre absence lors du cours de ${matiere} le ${date}.\n\nMerci de nous fournir un justificatif dans les plus brefs délais.\n\nCordialement,\nL'Administration`;
}
